<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GaleriController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// aksi dan view dari controller
// login
Route::post('/loginn', [GaleriController::class, 'login']);

// regis
Route::post('/regis', [GaleriController::class, 'regis']);

// awal
Route::get('/GaleriFoto', [GaleriController::class, 'tampilAwal']);

// logout
Route::get('/logout', [GaleriController::class, 'logout']);

// tambah dan view album
Route::get('/album', [GaleriController::class, 'tampilAlbum']);
Route::post('/buat', [GaleriController::class, 'buatAlbum']);

// tambah dan view foto
Route::get('/unggah', [GaleriController::class, 'pilihAlbum']);
Route::get('/homee', [GaleriController::class, 'tampilFoto']);
Route::post('/unggah', [GaleriController::class, 'unggahFoto']);

// view saat album di klik
Route::get('/lihatAlbum/{ALbumID}', [GaleriController::class, 'isiAlbum']);

// view saat foto di klik
Route::get('/foto/{FotoID}', [GaleriController::class, 'isiFoto']);

// komentar
Route::post('/komen/{FotoID}', [GaleriController::class, 'baruKomen']);

// like
Route::post('/like/{FotoID}', [GaleriController::class, 'like']);


// view aksi
Route::get('/loginn', function () {
    return view('aksi.login');
});
Route::get('/regis', function () {
    return view('aksi.register');
});
Route::get('/buat', function () {
    return view('aksi.buat');
});




