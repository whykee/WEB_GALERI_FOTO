<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: linear-gradient(to right, #ffc6c7 , #faeee7);
            height: 100vh;
            padding-top: 18vh;
        }
    </style>
  </head>
  <body>
    <!-- navbar -->
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- form -->
    <div class="container">
        <!-- kembali -->
        <div class="me-5">
            <a href="/album"><button class="btn rounded-pill px-3" style="background: hotpink;"><i class="fa-solid fa-arrow-left" style="font-size: 20px;"></i></button></a>
        </div>
        <!-- card -->
        <div class="card mb-3 mx-auto py-5 rounded-5 shadow-lg" style="width: 130vh; background-color: antiquewhite;">
            <div class="row g-0">
                <div class="col-md-6 mx-auto">
                <form action="/buat" method="POST">
                <?php echo csrf_field(); ?>
                    <h3 class="text-center">ALBUM</h3>
                    <div class="mb-3">
                        <label class="form-label fw-bolder pt-5">Nama Album :</label>
                        <input type="text" class="form-control rounded-pill shadow-sm" name="nama">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bolder">Deskripsi :</label>
                        <input type="text" class="form-control rounded-pill shadow-sm" name="deskripsi">
                    </div>

                    <a href="/album"><button type="submit" class="btn px-4 rounded-pill fw-bolder mt-5" style="background: hotpink;  margin-left: 190px">BUAT</button></a>
                </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Kelas 12\Ukk\resources\views/aksi/buat.blade.php ENDPATH**/ ?>