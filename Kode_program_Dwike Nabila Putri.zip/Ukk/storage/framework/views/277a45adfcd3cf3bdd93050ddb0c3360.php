<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .navbar-brand {
            font-family: Times;
            font-weight: bold;
        }
    </style>
  </head>
  <body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg fixed-top bg-light shadow-lg">
    <div class="container">
        <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('img/gf.png')); ?>" width="40" class="mb-2 me-1" alt="Logo"   >
        GaleriFoto
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item pb-1 fw-bolder">
            <a class="nav-link active" aria-current="page" href="/homee">Home</a>
            </li>
            <li class="nav-item pb-1 fw-bolder">
            <a class="nav-link active" aria-current="page" href="/album">Album</a>
            </li>
        </ul>
        </div>
        
        <!-- menampilkan nama user yang sudah login -->
        <span class="navbar-text mx-3 fw-bolder">
            Welcome, <?php echo e(session('user')->Username); ?> 
        </span>
        <a href="/logout"><button class="btn rounded-pill px-4 fw-bold" style="background: hotpink;" type="submit">Logout</button></a>
    </div>
    </nav>
            
    <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/1affd344f4.js" crossorigin="anonymous"></script>
    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html> <?php /**PATH C:\Kelas 12\Ukk\resources\views/nav.blade.php ENDPATH**/ ?>