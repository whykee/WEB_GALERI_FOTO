<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
      body {
        background-image: linear-gradient(to right, lightpink , linen);
        height: 100vh;
        padding-top: 28vh;
      }
      .navbar-brand {
        font-family: 'Times';
        font-weight: bold;
      }
      h1, p, h5 {
        font-family: 'Times';
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);  
      }
      .card {
        transition: transform 0.5s
        }
      .card:hover{
        transform: scale(1.1);
      }
    </style>
  </head>
  <body>
    <!-- navbar -->
    <nav class="navbar fixed-top bg-light shadow-lg">
    <div class="container">
        <a class="navbar-brand">
        <img src="img/gf.png" width="40" class="mb-2 me-1" alt="Logo"   >
        GaleriFoto
        </a>
         <a href="/loginn"><button class="btn rounded-pill px-4 fw-bold" style="background: hotpink;" type="submit">Mulai!</button></a>
    </div>
    </nav>

    <!-- isi -->
    <div class="container mb-5">
      <div class="row g-2">
        <div class="col-md-6">
          <img src="img/albm.png" class="w-75 ps-5">
        </div>
        <div class="col-md-6">
          <h1 class="display-4 pt-4 fw-bolder">Selamat datang di <span style="color: hotpink;">GALERIFOTO!</span></h1>
          <p class="fs-5 pt-3">Unggah semua momen tak terlupakanmu dan jadikan kenangan abadi.<br> Setiap foto adalah kisah, setiap kisah adalah bagian dari perjalananmu. <br> Mari buat galeri penuh warna dan kebahagiaan bersama-sama! 📸✨</p>
          <a href="#foto"><button class="btn rounded-pill px-4 fw-bold" style="background: hotpink;" type="submit">Lihat Foto Terbaru</button></a>
        </div>
      </div>
    </div>

    <!-- ini foto yang terbaru -->
    <div class="container" id="foto" style="padding-top: 16vh;">
    <div class="row">
        <h1 class="fw-bold fs-1 pb-4 text-center" style="font-family: Times;">TERBARU</h1>
        <p class="fs-5 text-center pb-4" style="font-family: Times;">~ Tangkap setiap foto dan ciptakan albummu, karena kenangan abadi menunggu dirimu  ~</p>
        <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 py-5 ps-5 mb-4">
            <div class="card shadow" style="width: 20rem; height: 24rem;">
                <a href=""><img src="<?php echo e(Storage::url($fto->LokasiFile)); ?>" class="card-img-top  rounded-2"  height="240"></a>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($fto->JudulFoto); ?></h5>
                    <p class="card-text"><?php echo e($fto->DeskripsiFoto); ?></p>
                    <p class="card-text"><?php echo e($fto->TanggalUnggah); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Kelas 12\Ukk\resources\views/web/awal.blade.php ENDPATH**/ ?>