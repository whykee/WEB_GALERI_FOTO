<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: linear-gradient(to right, #ffc6c7 , #faeee7);
            height: 100vh;
            padding-top: 15vh;
        }
    </style>
</head>
<body>
    <!-- navbar -->
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- kembali -->
    <div class="ms-5 ps-5">
        <a href="/homee"><button class="btn rounded-pill px-3" style="background: hotpink;"><i class="fa-solid fa-arrow-left" style="font-size: 20px;"></i></button></a>
    </div>

    <!-- button aksi -->
    <center><a href="/unggah"><button class="btn rounded-pill px-4 fw-bolder" style=" background: hotpink;" type="submit"><i class="fa-solid fa-plus pe-2"></i>Unggah Foto</button></a>
    <a href="/buat"><button class="btn rounded-pill px-4 fw-bolder" style=" background: hotpink;" type="submit"><i class="fa-solid fa-plus pe-2"></i>Buat Album</button></a></center>
   

    <!-- isi -->
    <div class="container pt-5">
        <div class="row">  
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card ps-2 rounded-4 shadow" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title pb-3"><?php echo e($item->NamaAlbum); ?></h5>
                        <p class="card-text" style="height: 4rem;"><?php echo e($item->Deskripsi); ?></p>
                        <a href="/lihatAlbum/<?php echo e($item->AlbumID); ?>"><button class="btn rounded-pill px-4 fw-bolder" style=" background: hotpink;" type="submit">Lihat!</button></a>
                        <!-- <a href="/hapus/album/<?php echo e($item->AlbumID); ?>" style="color: red; font-size: 20px;"><i class="fa-solid fa-trash"></i></a>  -->
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/1affd344f4.js" crossorigin="anonymous"></script>
    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Kelas 12\Ukk\resources\views/web/album.blade.php ENDPATH**/ ?>