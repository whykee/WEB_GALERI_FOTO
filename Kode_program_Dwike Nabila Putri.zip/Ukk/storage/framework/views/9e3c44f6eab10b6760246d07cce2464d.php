<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: linear-gradient(to right, #ffc6c7 , #faeee7);
            height: 100vh;
            padding-top: 15vh;
        }
    </style>
</head>
<body>
    <!-- navabr -->
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- isi-->
    <div class="container">
        <!-- kembali -->
        <div class="mb-4">
            <a href="/album"><button class="btn rounded-pill px-3" style="background: hotpink;"><i class="fa-solid fa-arrow-left" style="font-size: 20px;"></i></button></a>
        </div>
        <div class="row">
            <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 py-3">
                        <div class="card shadow rounded-3" style="width: 18rem; height: 25rem;">
                        <a href="/foto/<?php echo e($fto->FotoID); ?>"><img src="<?php echo e(Storage::url($fto->LokasiFile)); ?>" class="card-img-top rounded-2"  height="240" alt="..."></a>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($fto->JudulFoto); ?></h5>
                                <p class="card-text"><?php echo e($fto->DeskripsiFoto); ?></p>
                                <!-- <a href="/hapus/foto/<?php echo e($fto->FotoID); ?>" style="color: red; font-size: 20px;"><i class="fa-solid fa-trash"></i></a>   -->
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/1affd344f4.js" crossorigin="anonymous"></script>
    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Kelas 12\Ukk\resources\views/web/isiAlbum.blade.php ENDPATH**/ ?>