<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: linear-gradient(to right, #ffc6c7 , #faeee7);
            height: 100vh;
            padding-top: 15vh;
        }
    </style>
  </head>
  <body>
     <!-- navbar -->
    @include('nav')

    <!-- isi -->
    <div class="container">
        <!-- kembali -->
        <div class="me-5">
            <a href="/homee"><button class="btn rounded-pill px-3" style="background: hotpink;"><i class="fa-solid fa-arrow-left" style="font-size: 20px;"></i></button></a>
        </div>
        <!-- Card -->
        <div class="card mb-3 mx-auto py-5 rounded-5 shadow" style="width: 140vh; background-color: antiquewhite;">
            <div class="row g-0">
                <div class="col-md-6  d-flex align-items-center px-5">
                    <img src="{{ Storage::url($foto->LokasiFile) }}" width="455" class="rounded-4 shadow">
                </div>
                <div class="col-md-6">
                    <div class="card-body">
                        <span class="fw-bolder" style="margin-left: 42vh;">
                            {{ \App\Models\User::where('UserID',$foto->UserID)->first()->NamaLengkap }} 
                        </span>
                        <h5 class="display-5 card-title pb-4 pt-4 ms-4 fw-bold">{{ $foto->JudulFoto }}</h5>
                        <p class="card-text ms-4">{{ $foto->DeskripsiFoto }}</p>
                    </div>
                    <div class="pt-3">
                        <!-- ini komen -->
                        <div class="d-flex flex-column text-stars ms-5" style="margin-top: 18vh;">
                        @if($komentar->isEmpty())
                            <div class="mb-2">
                                <span class="fw-bold">Belum ada komentar.</span>
                            </div>
                        @else
                            @foreach($komentar as $komen)
                                <div class="mb-2">
                                    <div class="fw-bold text-muted">{{ \App\Models\User::where('UserID',$komen->UserID)->first()->Username }} <span class="fw-bolder" style="font-size: 12px;">{{ $komen->TanggalKomentar }}</span></div>
                                    <span class="fw-bolder">{{ $komen->IsiKomentar }}</span>
                                </div>
                            @endforeach
                        @endif
                    </div>
                    <div class="pt-2" style="margin-left: 53vh;">
                       <!-- ini like dan form untuk like -->
                       <form action="/like/{{$foto->FotoID}}" method="post">
                        @csrf
                            @if ($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()) 
                                <button class="px-3 ms-2" style="background: none; border: none;" type="submit"><i class="fa-solid fa-heart ps-3" style="color: red; font-size: 25px;"></i></button>
                                    {{ $like->where('FotoID', $foto->FotoID)->count() }}
                            @else
                                <button class="px-3 ms-2" style="background: none; border: none;" type="submit"><i class="fa-solid fa-heart ps-3" style="color: black; font-size: 25px;"></i></button>
                                    {{ $like->where('FotoID', $foto->FotoID)->count() }}
                        @endif
                    </form>
                    </div>
                    <!-- ini form untuk komen -->
                    <div class="pt-3">
                        <form class="d-flex" action="/komen/{{$foto->FotoID}}" method="post">
                            @csrf
                            <input class="form-control me-2 shadow-sm  rounded-pill ms-5" type="text" name="komen" placeholder="Masukkan Komentar..." style="width: 49vh;">
                            <button class="btn rounded-pill px-3" style="border: none;" type="submit"><i class="fa-solid fa-paper-plane pt-2" style="font-size: 20px;"></i></button>
                            <div class="ps-2 pt-2">{{ $komentar->where('FotoID', $foto->FotoID)->count() }}</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br><br><br>

     <!-- FONT AWESOME -->
     <script src="https://kit.fontawesome.com/1affd344f4.js" crossorigin="anonymous"></script>
    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>