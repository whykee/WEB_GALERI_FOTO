<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
         body {
            background: linear-gradient(to right, lightpink , linen);
            height: 100vh;
            padding-top: 20vh;
        }
        .card {
            transition: transform 0.5s
        }
        .card:hover{
            transform: scale(1.1); /* Perbesar gambar saat dihover */
        }
    </style>
</head>
<body>
    <!-- navbar -->
    @include('nav')

    <!-- isi -->
    <div class="container">
        <div class="row">
            @foreach($foto as $fto)
                    <div class="col-md-3 py-3">
                        <div class="card shadow rounded-3" style="width: 18rem;">
                        <a href="/foto/{{ $fto->FotoID }}"><img src="{{ Storage::url($fto->LokasiFile) }}" class="card-img-top rounded-2"  height="240" alt="..."></a>
                            <div class="card-body">
                                <h5 class="card-title">{{ $fto->JudulFoto }}</h5>
                                <p class="card-text">{{ $fto->DeskripsiFoto }}</p> 
                            </div>
                        </div>
                    </div>
            @endforeach
        </div>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>