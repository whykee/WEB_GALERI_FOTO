<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
       body {
            background: linear-gradient(to right, lightpink , linen);
            height: 100vh;
            padding-top: 18vh;
        }
    </style>
</head>
<body>

    <!-- ini form -->
    <div class="container">
        <div class="card mb-3 mx-auto py-5 rounded-5 shadow-lg" style="width: 130vh; background-color: antiquewhite;">
            <div class="row g-0">
                <div class="col-md-6">
                <form action="/loginn" method="POST">
                @csrf
                <h3 class="text-center">LOGIN</h3>

                <!-- pesan, kesalahan -->
                <center><p class="fw-bold text-danger pt-2">{{ session('pesan') }}</p></center>
                <center><p class="fw-bold text-primary pt-2">{{ session('berhasil') }}</p></center>
                
                    <div class="mb-3" style="margin-left: 60px;">
                        <label class="form-label pt-3 fw-bolder">Masukkan Email :</label>
                        <input type="email" class="form-control rounded-pill shadow-sm" style="width: 51vh;" name="email">
                    </div>
                    <div class="mb-3" style="margin-left: 60px;">
                        <label class="form-label pt-3 fw-bolder">Masukkan Password :</label>
                        <input type="password" class="form-control rounded-pill shadow-sm" style="width: 51vh;" name="password">
                    </div>
                    <div class="mb-3" style="margin-left: 60px;">
                        <p class="pt-3 fw-bolder">Belum Punya Akun? <a href="/regis" style="text-decoration: none; color: hotpink;">REGISTER</a> Dulu!</p>
                    </div>

                    <div class="pt-3">
                        <a href="/homee"><button type="submit" class="btn px-4 rounded-pill fw-bolder" style="background: hotpink; margin-left: 190px;">MASUK</button></a>
                    </div>
                </form>
                </div>
                <div class="col-md-6 ps-5 pt-4">
                <img src="img/mm.png" width="330" class="rounded-circle shadow-sm">
                </div>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>