<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GALERIFOTO</title>
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            background-image: linear-gradient(to right, #ffc6c7 , #faeee7);
            height: 100vh;
            padding-top: 15vh;
        }
    </style>
  </head>
  <body>
    <!-- navbar -->
    @include('nav')

    <!-- ini form -->
    <div class="container">
        <!-- kembali -->
        <div class="me-5">
            <a href="/album"><button class="btn rounded-pill px-3" style="background: hotpink;"><i class="fa-solid fa-arrow-left" style="font-size: 20px;"></i></button></a>
        </div>
        <!-- card -->
        <div class="card mb-3 mx-auto py-4 rounded-5 shadow-lg" style="width: 130vh; background-color: antiquewhite;">
            <div class="row g-0">
                <div class="col-md-6 mx-auto">
                <form action="/unggah" method="POST" enctype="multipart/form-data">
                @csrf
                    <h3 class="text-center">FOTO</h3>
                    <div class="mb-3">
                        <label class="form-label fw-bolder pt-4">Judul Foto :</label>
                        <input type="text" class="form-control rounded-pill shadow-sm" name="judul">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bolder">Deskripsi Foto :</label>
                        <input type="text" class="form-control rounded-pill shadow-sm" name="deskripsi">
                    </div>
                    <div class="mb-3">
                      <label class="form-label fw-bolder">Pilih Foto :</label>
                      <input type="file" class="form-control rounded-pill shadow-sm" name="foto">
                    </div>
                    <div class="mb-3">
                      <label class="form-label fw-bolder">Pilih Album :</label>
                      <select class="form-select rounded-pill shadow-sm" name="album">
                        @foreach($album as $alb)
                            <option value="{{ $alb->AlbumID }}">{{ $alb->NamaAlbum }}</option>
                        @endforeach
                      </select>
                    </div>

                    <a href="/homee"><button type="submit" class="btn px-4 rounded-pill fw-bolder mt-4" style="background: hotpink;  margin-left: 190px">TAMBAH</button></a>
                </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>