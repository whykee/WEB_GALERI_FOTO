<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Album;
use App\Models\Foto;
use App\Models\Komentar;
use App\Models\Like;

class GaleriController extends Controller
{
    // aksi login
    public function login (Request $request) {
        $data = User::where('Email', $request->input('email'))->where('Password', $request->input('password'))->first();
        if($data == null) {
            return redirect('/loginn')->with('pesan', 'Email Atau Password Salah!');
        }else{
            session()->put('user', $data);
            return redirect ('/homee');
        }
    }

    // aksi regis
    public function regis (Request $request) {
        $data = new User;

        $data->Username = $request->input('username');
        $data->Password = $request->input('password');
        $data->Email = $request->input('email');
        $data->NamaLengkap = $request->input('nama');
        $data->Alamat = $request->input('alamat');

        $data->save();

        return redirect('/loginn')->with('berhasil', 'Anda Sudah Terdaftar, Silakan Login!');
    }

    // aksi logout
    public function logout () {
        session()->flush();
        return redirect('/GaleriFoto');
    }

    // view foto pada hal awal
    public function tampilAwal() {
        // disini merupakan fungsi mengambil foto terbaru dari terbesar dengan ID foto
        $foto = Foto::orderBy('FotoID', 'desc')->take(3)->get();
    
        return view('web.awal', compact('foto'));
    }

      // view album
      public function tampilAlbum(){
        $data = Album::where('UserID', session('user')->UserID)->get();
        return view('web.album', compact('data'));
    }

    // aksi buat album
    public function buatAlbum(Request $request){
        $data = new Album();
        $data->NamaAlbum = $request->input('nama');
        $data->Deskripsi = $request->input('deskripsi');
        $data->TanggalDibuat = date('Y-m-d');
        $data->UserID = session('user')->UserID;
        $data->save();

        session()->put('album', $data);
        return redirect('/album');
    }

    // view home untuk pilih album
    public function pilihAlbum(){
        $album = Album::where('UserID', session('user')->UserID)->get();
        return view('aksi.unggah', compact('album'));
    }    

    // view album
    public function tampilFoto(){
        $foto = Foto::all();
        return view('web.home', compact('foto'));
    }

    // aksi buat foto
    public function unggahFoto (Request $request) {
        if($request->hasFile('foto')) {

            $locate = $request->file('foto')->store('public/images');

            $data = new Foto();
            $data->JudulFoto = $request->input('judul');
            $data->DeskripsiFoto = $request->input('deskripsi');
            $data->TanggalUnggah = date('Y-m-d H:i:s');
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->input('album');
            $data->UserID = session('user')->UserID;
    
            $data->save();
            
            session()->put('foto', $data);
            return redirect ('/homee');
        }else{
            return redirect('/unggah');
        }
    }

    // view album di klik
    public function isiAlbum($AlbumID) {
        $album = Album::find($AlbumID);
        $foto = Foto::where('AlbumID', $AlbumID)->get(); 
    
        return view('web.isiAlbum', compact('album', 'foto'));
    }   

    // view foto di klik
    public function isiFoto ($FotoID) {
        $foto = Foto::find($FotoID);
        $komentar = Komentar::where('FotoID', $FotoID)->get();
        $like = Like::where('FotoID', $FotoID)->get();
  
        return view('web.foto', compact('foto', 'komentar', 'like'))->with('pesan1', 'Login Terlebih Dahulu!');
    }

    // aksi komentar
    public function baruKomen(Request $request,$FotoID){

        $data = new Komentar;
        $data ->FotoID = $FotoID;
        $data ->UserID = session('user')->UserID;
        $data ->IsiKomentar = $request->input('komen');
        $data ->TanggalKomentar= date ('Y-m-d H:i:s');

        $data ->save();

        return redirect()->back();
    }
    
    // aksi like
    public function like($FotoID) {
        $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
    
        if(!$cek){
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->TanggalLike = now(); 
            $data->save();
    
            return redirect()->back();
        } else {
            $cek->delete();
            return redirect()->back();
        }
    }       
}